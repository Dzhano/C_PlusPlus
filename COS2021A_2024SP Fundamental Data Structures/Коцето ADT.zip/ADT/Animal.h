#ifndef ANIMAL_H
#define ANIMAL_H

#include <iostream>
#include <string>

class Animal {
private:
    std::string Name;
    int Age;
    std::string ID;
    bool Adopted;
    Animal* Parent;

public:
    Animal();
    Animal(const std::string& name, int age, const std::string& id, bool adopted, Animal* parent);

    void setName(const std::string& name);
    void setAge(int age);
    void setID(const std::string& id);
    void setAdopted(bool adopted);
    void setParent(Animal* parent);

    std::string getName() const;
    int getAge() const;
    std::string getID() const;
    bool isAdopted() const;
    Animal* getParent() const;

    virtual std::string makeSound() const = 0;
    static void loadData(const std::string& filePath);
};

#endif
