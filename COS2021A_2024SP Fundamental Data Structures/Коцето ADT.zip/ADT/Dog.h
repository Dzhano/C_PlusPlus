#ifndef DOG_H
#define DOG_H

#include "Animal.h"

class Dog : public Animal {
private:
    std::string Size;
    std::string EnergyLevel;
    std::string Breed;

public:
    Dog();
    Dog(const std::string& name, int age, const std::string& id, bool adopted, Animal* parent, const std::string& size, const std::string& energyLevel, const std::string& breed);

    void setSize(const std::string& size);
    void setEnergyLevel(const std::string& energyLevel);
    void setBreed(const std::string& breed);

    std::string getSize() const;
    std::string getEnergyLevel() const;
    std::string getBreed() const;

    std::string makeSound() const = 0;
};

#endif
