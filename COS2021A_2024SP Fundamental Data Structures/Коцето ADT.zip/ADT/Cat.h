#ifndef CAT_H
#define CAT_H

#include "Animal.h"

class Cat : public Animal {
private:
    std::string FurType;
    std::string SpecialNeeds;

public:
    Cat();
    Cat(const std::string& name, int age, const std::string& id, bool adopted, Animal* parent, const std::string& furType, const std::string& specialNeeds);

    void setFurType(const std::string& furType);
    void setSpecialNeeds(const std::string& specialNeeds);

    std::string getFurType() const;
    std::string getSpecialNeeds() const;

    std::string makeSound() const = 0;
};

#endif
