#ifndef PERSIAN_H
#define PERSIAN_H

#include "Cat.h"

class Persian : public Cat {
private:
    std::string SpecialCharacteristic;

public:
    Persian();
    Persian(const std::string& name, int age, const std::string& id, bool adopted, Animal* parent, const std::string& furType, const std::string& specialNeeds);

    void setSpecialCharacteristic(const std::string& specialCharacteristic);
    std::string getSpecialCharacteristic() const;

    std::string makeSound() const override;
};

#endif
