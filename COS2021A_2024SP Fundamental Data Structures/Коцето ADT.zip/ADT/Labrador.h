#ifndef LABRADOR_H
#define LABRADOR_H

#include "Dog.h"

class Labrador : public Dog {
private:
    std::string SpecialCharacteristic;

public:
    Labrador();
    Labrador(const std::string& name, int age, const std::string& id, bool adopted, Animal* parent, const std::string& size, const std::string& energyLevel, const std::string& breed);

    void setSpecialCharacteristic(const std::string& specialCharacteristic);
    std::string getSpecialCharacteristic() const;

    std::string makeSound() const override;
};

#endif
