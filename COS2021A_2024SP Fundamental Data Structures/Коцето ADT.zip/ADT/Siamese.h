#ifndef SIAMESE_H
#define SIAMESE_H

#include "Cat.h"

class Siamese : public Cat {
private:
    std::string SpecialCharacteristic;

public:
    Siamese();
    Siamese(const std::string& name, int age, const std::string& id, bool adopted, Animal* parent, const std::string& furType, const std::string& specialNeeds);

    void setSpecialCharacteristic(const std::string& specialCharacteristic);
    std::string getSpecialCharacteristic() const;

    std::string makeSound() const override;
};

#endif 
